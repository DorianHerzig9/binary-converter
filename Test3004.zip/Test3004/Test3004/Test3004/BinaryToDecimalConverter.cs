﻿namespace Test3004
{
    public class BinaryToDecimalConverter
    {
        public int ConvertToDecimal(string binaryNumber)
        {
            return Convert.ToInt32(binaryNumber, 2);
        }
    }
}
