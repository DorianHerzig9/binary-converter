﻿namespace Test3004
{
    public class BinaryConverter
    {
        public string ConvertToBinary(int decimalNumber)
        {
            string binaryString = string.Empty;

            while (decimalNumber > 0)
            {
                //Stackoverflow
                int remainder = decimalNumber % 2;
                binaryString = remainder + binaryString;
                decimalNumber /= 2;
            }

            return binaryString;
        }
    }
}

