﻿namespace Test3004
{
    class Program
    {
        static void Main()
        {
            string answer;
            do
            {
                try
                {
                    Console.Write("Would you like to input a decimal or binary number? d/b: ");
                    string choice = Console.ReadLine();

                    if (choice == "d")
                    {
                        Console.Write("Enter a decimal number: ");
                        int decimalNumber = int.Parse(Console.ReadLine() ?? string.Empty);

                        BinaryConverter converter = new BinaryConverter();
                        string binaryResult = converter.ConvertToBinary(decimalNumber);
                        Console.WriteLine("Binary: {0}", binaryResult);
                    }
                    else if (choice == "b")
                    {
                        Console.Write("Enter a binary number: ");
                        string binaryNumber = Console.ReadLine();

                        BinaryToDecimalConverter decimalConverter = new BinaryToDecimalConverter();
                        int decimalResult = decimalConverter.ConvertToDecimal(binaryNumber);
                        Console.WriteLine("Decimal: {0}", decimalResult);
                    }
                    else
                    {
                        Console.WriteLine("Please enter 'd' for decimal or 'b' for binary next time.");
                    }
                }
                catch
                {
                    Console.WriteLine("Only enter the appropriate number.");
                }

                Console.Write("Would you like to input a new number? y/n: ");
                answer = Console.ReadLine();

            } while (answer == "y");
        }
    }
}